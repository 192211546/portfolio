'use strict';
/* Customize project facts here. Add only verified technologies and URLs.
   Resume: put your PDF at assets/resume.pdf, beside this site's files.
   Contact service: replace the mailto navigation in the submit listener with
   a POST to your verified form-service endpoint. Keep private API keys off the
   browser. Show delivery confirmation ONLY after the service reports success.
   The current form opens a draft in the visitor's own email client, not a server. */
const projectDetails = {
  airline: {
    title: 'Improving Airline Ticket Pricing with Dynamic Pricing Models',
    description: 'Developed a Random Forest Regression model to predict airline ticket prices using factors such as demand, booking lead time, seasonality, and flight details. Compared its performance with Neural Networks, Time Series Analysis, and Linear Regression using MAE, RMSE, and R².',
    contributions: ['Predictive modeling using Random Forest Regression.', 'Feature-based price prediction incorporating demand, booking lead time, seasonality, and flight details.', 'Regression analysis and comparison with alternative modeling approaches.', 'Model performance evaluation using MAE, RMSE, and R².'],
    tags: ['Random Forest Regression', 'Neural Networks', 'Time Series Analysis', 'Linear Regression']
  },
  battery: {
    title: 'Predictive Modeling for Electric Vehicle Battery Life Optimization',
    description: 'Built a predictive analytics model to optimize electric vehicle battery lifespan using usage pattern analysis and machine learning in Python. Applied time-series analysis and feature engineering to identify degradation trends and recommend optimized charging cycles.',
    contributions: ['Predictive analytics for battery lifespan.', 'Time-series analysis of usage patterns.', 'Feature engineering to identify battery degradation trends.', 'Recommendations for optimized charging cycles.'],
    tags: ['Python', 'Machine Learning', 'Predictive Analytics', 'Time Series', 'Feature Engineering']
  },
  plant: {
    title: 'Plant as a Pet',
    description: 'Engineered an interactive product called “Plant as a Pet,” blending IoT and emotional design to treat plants like living companions. The concept featured smart care with sensor-based feedback and visual cues.',
    contributions: ['Product innovation integrating plant care and emotional design.', 'Interactive design to make plants feel like living companions.', 'IoT concept for smart plant care.', 'Sensor-based feedback and visual cues.'],
    tags: ['IoT Concept', 'Interactive Design', 'Sensor Feedback', 'Product Innovation']
  }
};
const menuButton = document.querySelector('.menu-toggle');
const navigation = document.getElementById('navigation');
function closeMenu() {
  navigation.classList.remove('open');
  menuButton.setAttribute('aria-expanded', 'false');
  menuButton.setAttribute('aria-label', 'Open navigation');
}
menuButton.addEventListener('click', () => {
  const open = menuButton.getAttribute('aria-expanded') !== 'true';
  navigation.classList.toggle('open', open);
  menuButton.setAttribute('aria-expanded', String(open));
  menuButton.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
});
navigation.querySelectorAll('a').forEach(link => link.addEventListener('click', closeMenu));
document.addEventListener('click', event => {
  if (!navigation.contains(event.target) && !menuButton.contains(event.target)) closeMenu();
});
window.matchMedia('(min-width: 801px)').addEventListener('change', event => { if (event.matches) closeMenu(); });
const sections = [...document.querySelectorAll('main > section[id]')];
const navLinks = [...navigation.querySelectorAll('a')];
let scheduled = false;
function setActiveSection() {
  const offset = 155;
  let current = sections[0];
  for (const section of sections) {
    if (section.getBoundingClientRect().top <= offset) current = section;
  }
  if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 10) current = sections[sections.length - 1];
  navLinks.forEach(link => {
    const active = link.getAttribute('href') === '#' + current.id;
    link.classList.toggle('active', active);
    if (active) link.setAttribute('aria-current', 'location');
    else link.removeAttribute('aria-current');
  });
  scheduled = false;
}
window.addEventListener('scroll', () => {
  if (!scheduled) { scheduled = true; requestAnimationFrame(setActiveSection); }
}, { passive: true });
setActiveSection();
const reveals = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) { entry.target.classList.add('visible'); observer.unobserve(entry.target); }
    });
  }, { threshold: .06 });
  reveals.forEach(element => observer.observe(element));
} else reveals.forEach(element => element.classList.add('visible'));
document.querySelectorAll('.skill-tab').forEach(button => {
  button.addEventListener('click', () => {
    document.querySelectorAll('.skill-tab').forEach(tab => tab.setAttribute('aria-pressed', String(tab === button)));
    document.querySelectorAll('.skill-card').forEach(card => {
      card.hidden = button.dataset.filter !== 'all' && card.dataset.category !== button.dataset.filter;
    });
  });
});
const modal = document.getElementById('project-modal');
const panel = modal.querySelector('.modal-panel');
const closeButton = modal.querySelector('.modal-close');
let previousFocus = null;
let previousOverflow = '';
function closeModal() {
  if (modal.hidden) return;
  modal.hidden = true;
  document.body.style.overflow = previousOverflow;
  previousFocus?.focus();
}
document.querySelectorAll('[data-project]').forEach(button => {
  button.addEventListener('click', () => {
    const project = projectDetails[button.dataset.project];
    if (!project) return;
    previousFocus = button;
    document.getElementById('modal-title').textContent = project.title;
    document.getElementById('modal-description').textContent = project.description;
    const contributions = document.getElementById('modal-contributions');
    contributions.replaceChildren(...project.contributions.map(text => {
      const item = document.createElement('li'); item.textContent = text; return item;
    }));
    const tags = document.getElementById('modal-tags');
    tags.replaceChildren(...project.tags.map(text => {
      const tag = document.createElement('span'); tag.className = 'tag'; tag.textContent = text; return tag;
    }));
    modal.hidden = false;
    previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    closeButton.focus();
  });
});
closeButton.addEventListener('click', closeModal);
modal.addEventListener('click', event => { if (event.target === modal) closeModal(); });
document.addEventListener('keydown', event => {
  if (event.key === 'Escape') { closeModal(); closeMenu(); }
  if (event.key === 'Tab' && !modal.hidden) {
    const focusable = [...panel.querySelectorAll('button,a[href],input,textarea,[tabindex="0"]')];
    const first = focusable[0]; const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last?.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus(); }
  }
});
let toastTimer;
function notify(text) {
  const toast = document.getElementById('toast');
  toast.textContent = text; toast.hidden = false;
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => { toast.hidden = true; }, 7000);
}
// Probe before downloading to avoid serving a broken link or an HTML fallback as PDF.
document.querySelectorAll('.resume-link').forEach(link => {
  link.addEventListener('click', async event => {
    event.preventDefault();
    try {
      const response = await fetch(link.getAttribute('href'));
      if (!response.ok) throw new Error('Missing resume');
      const blob = await response.blob();
      const signature = await blob.slice(0, 5).text();
      if (signature !== '%PDF-') throw new Error('Not a PDF');
      const url = URL.createObjectURL(blob);
      const download = document.createElement('a');
      download.href = url; download.download = 'Mandli-Santhosh-Reddy-Resume.pdf';
      document.body.append(download); download.click(); download.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 10000);
    } catch {
      notify('The resume PDF is not available yet. Please email Santhosh to request a copy.');
    }
  });
});
const form = document.getElementById('contact-form');
form.querySelectorAll('input,textarea').forEach(field => {
  field.addEventListener('input', () => { field.setCustomValidity(''); document.getElementById('form-status').textContent = ''; });
});
form.addEventListener('submit', event => {
  event.preventDefault();
  for (const field of form.querySelectorAll('[required]')) {
    field.setCustomValidity(field.value.trim() ? '' : 'Please complete this field.');
  }
  if (!form.reportValidity()) return;
  const data = new FormData(form);
  const value = key => String(data.get(key) || '').trim();
  const body = 'Name: ' + value('name') + '\nEmail: ' + value('email') + '\n\n' + value('message');
  const draft = 'mailto:Santhoshreddy9705@gmail.com?subject=' + encodeURIComponent(value('subject')) + '&body=' + encodeURIComponent(body);
  document.getElementById('form-status').textContent = 'Your email draft is ready. Send it from your email app; nothing has been sent by this site.';
  window.location.href = draft;
});
document.getElementById('year').textContent = new Date().getFullYear();
document.querySelector('.top-btn').addEventListener('click', () => {
  document.getElementById('home').scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' });
  const homeLink = navigation.querySelector('a[href="#home"]');
  homeLink.focus({ preventScroll: true });
});
